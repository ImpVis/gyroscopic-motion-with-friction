<template>
    <div>
        <iv-visualisation :title="pageName" :vue_config="vue_config" :page_number="1" >           
            <template #hotspots>

                <iv-toggle-hotspot position="bottom" title="Controls" style=" z-index: 2;">
                    
                    <div style="width:100%; float:bottom;"> 
                        <label for="angleslider"> Angle to vertical (radians): </label>
                        <iv-slider id="theta" ref="angleController" :resetButton=false @sliderChangedbyDragging="sliderChange" @sliderChangedbyClick="sliderChange" @click="resetGyro" theme="Lime" :min="0" :max="1.026" :init_val="0" :step="0.1" :tick_step="0.5" />
                    </div>

                    <div style="width:100%; float:bottom;">
                        <div style="width: 100px; float:left; margin:10px">
                            <label for="toggleBasic"> Stop/Start </label>
                            <iv-toggle-basic id="toggleBasic" @input="toggleChange"> </iv-toggle-basic>
                        </div>

                    </div>

                    
                </iv-toggle-hotspot>

                <iv-toggle-hotspot position="right" title="Diagram" style="width:30vw; z-index: 2;">
                    
                    <figure>
                        <img src = "assets/image.png" width=100% >
                        <figcaption>
                        <p align="center">
                        Vector Diagram for gyroscope in motion.
                        <b>
                        N
                        </b>
                        is the torque,
                        <br/>
                        <b>
                        L
                        </b>
                        is the angular momentum,
                        <br/>
                        <b>
                        a
                        </b>
                        is the position vector.
                        </p>
                        </figcaption>    
                    
                    </figure>
                </iv-toggle-hotspot>
                



                                
                <iv-pane position="left" format="push">
                    <iv-sidebar-content :showPagination="true">
                        <iv-sidebar-section title="Instructions" icon="question" theme="Lime" >
                            <p>
                                Open the controls tab to adjust the gycroscopes's angle to the vertical. 
                                Press the stop/start toggle to start the animation.
                            </p>
                            <p>
                                What do you notice? Open the diagram hotspot on the right 
                                to see a vector diagram of the gyroscope to help you.
                            </p>
                        </iv-sidebar-section>
                        
                        <iv-sidebar-section title="Theory" icon="microscope" >
                            <p>
                                The torque experienced by a gyroscope is in a direction perpendicular to it's angular 
                                momentum about it's own rotation axis (which is about the rod passing through the flywheel). 
                                This means the change in angular momentum, in the same direction as the torque, is also 
                                perpendicular to it's own axis (recall that torque is the rate of change of angular momentum). 
                                
                            
                            </p>

                            <p>   
                                As a result the angular momentum vector of the gyroscope begins to "follow" the torque; 
                                so the gyroscope itself begins to move around in a circle about the z axis, as the torque 
                                is always perpendicular to the angular momentum. 
                            </p>

                             <figure>
                                <img src =  "https://philschatz.com/physics-book/resources/Figure_11_07_04a.jpg" width=100% >
                                <figcaption>
                                <p>
                                    (linked from https://philschatz.com/physics-book/contents/m42184.html)
                                </p>
                                </figcaption>    
                            
                            </figure>

                        </iv-sidebar-section>

                        
                    </iv-sidebar-content>
                </iv-pane>


            </template>
                


            <div class="iv-welcome-message">
                <label for="7 columns">Gyroscopic motion:                </label>
                <div class="7 columns" id="test" ><!---plotting the image--></div>
                       
            </div>  
            
        </iv-visualisation>
    </div>
</template>
<script>
import vue_config from '../../vue.config.js';
// import Plotly from 'plotly.js';
import Plotly from 'plotly.js/dist/plotly.min.js';

export default {
    name:"frictionless",
    data(){
        return {
            pageName:"Gyroscopes - angle to vertical",
            vue_config,
            resetButton:false,
            toggleChanged:false,
            toggleChoice:false,
            hasSliderChanged:false,
            thetaVal:0
        }
    },

    props:{

    },
    methods:{
        resetGyro(){
            this.resetButton = true;
            },

        toggleChange(e){
            // console.log("here")
            // console.log(e)
            this.toggleChoice=e;
            this.toggleChanged=true;
        },

        sliderChange(e){
            this.thetaVal=e;
            this.hasSliderChanged=true;
            // console.log("here")
            // console.log(this.hasSliderChanged)
        },

        

    },
    mounted(){
        
        let v = this;

        //initializing variables
        let p1, p2, p3;
        let t = 0;
        let r = 12.5;
        //let played;
        let anim;
        let plt = {
            MaxTraceNo: 12,
            layout: {
                autosize: true,
                margin: {
                    l: 0, r: 0, b: 0, t: 1, pad: 5
                },
                scene: {
                    aspectmode: "cube",
                    xaxis: {
                        range: [-40, 40], autorange: false, zeroline: true, showspikes: false
                    },
                    yaxis: {
                        range: [-40, 40], autorange: false, zeroline: true, showspikes: false
                    },
                    zaxis: {
                        range: [-40, 40], autorange: false, zeroline: true, showspikes: false
                    }
                },
                hovermode: false,
                font: {
                    family: "Fira Sans",
                    size: 14
                }
            },
        };

      

        let theta = 0;
        let phi = 0 ;
        let azimuth = 0;
        let costheta = Math.cos(theta);
        let sintheta = Math.sin(theta);
        let cosazimuth = Math.cos(azimuth);
        let sinazimuth = Math.sin(azimuth);
        let cosphi = Math.cos(phi); // the first ones
        let sinphi = Math.sin(phi);
        let cosphi_2 = Math.cos(phi + 0.785398163); //offset by pi/4
        let sinphi_2 = Math.sin(phi + 0.785398163);
        let cosphi_3 = Math.cos(phi + 1.57079632679); //offset by pi/2
        let sinphi_3 = Math.sin(phi + 1.57079632679);
        let cosphi_4 = Math.cos(phi + 2.35619449019); //offset by 3pi/4
        let sinphi_4 = Math.sin(phi + 2.35619449019);
        let cosphi_5 = Math.cos(phi + 3.14159265359); //offset by pi
        let sinphi_5 = Math.sin(phi + 3.14159265359);
        let cosphi_6 = Math.cos(phi - 2.35619449019); //offset by 3pi/4
        let sinphi_6 = Math.sin(phi - 2.35619449019);
        let cosphi_7 = Math.cos(phi - 1.57079632679); //offset by pi/2
        let sinphi_7 = Math.sin(phi - 1.57079632679);
        let cosphi_8 = Math.cos(phi - 0.785398163); //offset by -pi/4
        let sinphi_8 = Math.sin(phi - 0.785398163);


        p1 = [0, 20.62 * sintheta, 38 * sintheta,  20.62 * sintheta + r * costheta * cosphi, 20.62 * sintheta + r * costheta * cosphi_2, 20.62 * sintheta + r * costheta * cosphi_3,20.62 * sintheta + r * costheta * cosphi_4, 20.62 * sintheta + r * costheta * cosphi_5, 20.62 * sintheta + r * costheta * cosphi_6, 20.62 * sintheta + r * costheta * cosphi_7, 20.62 * sintheta + r * costheta * cosphi_8, 20.62 * sintheta + r * costheta * cosphi];// reads like a matrix
        p2 = [0, 0, 0, r * sinphi, r*sinphi_2, r*sinphi_3,r*sinphi_4, r*sinphi_5, r*sinphi_6, r*sinphi_7, r*sinphi_8,  r * sinphi];
        p3 = [0, 20.62 * costheta,  38 * costheta,  20.62 * costheta - r * cosphi * sintheta, 20.62 * costheta - r * sintheta * cosphi_2, 20.62 * costheta - r * sintheta * cosphi_3, 20.62 * costheta - r * sintheta * cosphi_4, 20.62 * costheta - r * sintheta * cosphi_5, 20.62 * costheta - r * sintheta * cosphi_6, 20.62 * costheta - r * sintheta * cosphi_7, 20.62 * costheta - r * sintheta * cosphi_8, 20.62 * costheta - r * cosphi * sintheta];

        for (let i = 0; i < p1.length; i++) { // applying rotation matrix using a for loop, currently works
            let a = p1[i];
            p1[i] = a * cosazimuth - p2[i] * sinazimuth;
            p2[i] = a * sinazimuth + p2[i] * cosazimuth; }

        let int = {
            type: "scatter3d",
            x: p1,
            y: p2,
            z: p3,
        };


        Plotly.newPlot("test", [int], plt.layout);
        

        function reset() { //resets all the variables and draws the gyroscope at its initial position
            v.toggleChoice  = true;
            toggle();
            t = 0;
            let theta = 0;
            let phi = 0; //doesn't seem to be changing whenever i change the power of i????
            let costheta = Math.cos(theta);
            let sintheta = Math.sin(theta);
            let cosphi = Math.cos(phi);
            let sinphi = Math.sin(phi);
            let cosphi_2 = Math.cos(phi + 0.785398163); //offset by pi/4
            let sinphi_2 = Math.sin(phi + 0.785398163);
            let cosphi_3 = Math.cos(phi + 1.57079632679); //offset by pi/2
            let sinphi_3 = Math.sin(phi + 1.57079632679);
            let cosphi_4 = Math.cos(phi + 2.35619449019); //offset by 3pi/4
            let sinphi_4 = Math.sin(phi + 2.35619449019);
            let cosphi_5 = Math.cos(phi + 3.14159265359); //offset by pi
            let sinphi_5 = Math.sin(phi + 3.14159265359);
            let cosphi_6 = Math.cos(phi - 2.35619449019); //offset by 3pi/4
            let sinphi_6 = Math.sin(phi - 2.35619449019);
            let cosphi_7 = Math.cos(phi - 1.57079632679); //offset by pi/2
            let sinphi_7 = Math.sin(phi - 1.57079632679);
            let cosphi_8 = Math.cos(phi - 0.785398163); //offset by -pi/4
            let sinphi_8 = Math.sin(phi - 0.785398163);

            p1 = [0, 20.62 * sintheta, 38 * sintheta,  20.62 * sintheta + r * costheta * cosphi, 20.62 * sintheta + r * costheta * cosphi_2, 20.62 * sintheta + r * costheta * cosphi_3,20.62 * sintheta + r * costheta * cosphi_4, 20.62 * sintheta + r * costheta * cosphi_5, 20.62 * sintheta + r * costheta * cosphi_6, 20.62 * sintheta + r * costheta * cosphi_7, 20.62 * sintheta + r * costheta * cosphi_8, 20.62 * sintheta + r * costheta * cosphi];// reads like a matrix
            p2 = [0, 0, 0, r * sinphi, r*sinphi_2, r*sinphi_3,r*sinphi_4, r*sinphi_5, r*sinphi_6, r*sinphi_7, r*sinphi_8,  r * sinphi];
            p3 = [0, 20.62 * costheta,  38 * costheta,  20.62 * costheta - r * cosphi * sintheta, 20.62 * costheta - r * sintheta * cosphi_2, 20.62 * costheta - r * sintheta * cosphi_3, 20.62 * costheta - r * sintheta * cosphi_4, 20.62 * costheta - r * sintheta * cosphi_5, 20.62 * costheta - r * sintheta * cosphi_6, 20.62 * costheta - r * sintheta * cosphi_7, 20.62 * costheta - r * sintheta * cosphi_8, 20.62 * costheta - r * cosphi * sintheta];

            
            let int = {
                type: "scatter3d",
                x: p1,
                y: p2,
                z: p3,
            };

            Plotly.purge("test"); // removes any previous plotly plots
            Plotly.newPlot("test", [int], plt.layout); // plots the gyroscope plots
        }

        function toggle() { // changing the button name and calls play() function every 10 milliseconds to draw the gyrocope
            if (v.toggleChoice == true) {
                //$("#playPauseButton").html("play");
                v.toggleChoice = true;
                clearInterval(anim); //the clear interval means that it only stops at the end of the animation
                //$("div#test").stop(true, true);
            }
            else {
                //$("#playPauseButton").html("pause");
                v.toggleChoice = false;
                anim = setInterval(play, 80); // calls the play function every 10 milliseconds // changed to 80
            }
            return v.toggleChoice
        }



        function play() { // function that makes a plot of the gyroscope that changes every time it is called (because parameters are t dependent and the variable t is changed every loop)
            let azimuth = t*(3.14159265359 / 180) * 25;
            let theta = v.thetaVal; //parseFloat($("input#theta").val());//converts slider value into float, converts that into a decimal and then back into a float to be added;//parsefloat converts string into number but rounds also..
            //theta += (3.14159265359 / 6000)*(t*1.01); //num.toFixed function is used otherwise parsefloat rounds the value up
            let phi =  15*t ; //-0.012*t**2 //doesn't seem to be changing whenever i change the power of i????
            let costheta = Math.cos(theta);
            let sintheta = Math.sin(theta);
            let cosphi = Math.cos(phi);
            let sinphi = Math.sin(phi);
            let cosazimuth = Math.cos(azimuth);
            let sinazimuth = Math.sin(azimuth);
            let cosphi_2 = Math.cos(phi + 0.785398163); //offset by pi/4
            let sinphi_2 = Math.sin(phi + 0.785398163);
            let cosphi_3 = Math.cos(phi + 1.57079632679); //offset by pi/2
            let sinphi_3 = Math.sin(phi + 1.57079632679);
            let cosphi_4 = Math.cos(phi + 2.35619449019); //offset by 3pi/4
            let sinphi_4 = Math.sin(phi + 2.35619449019);
            let cosphi_5 = Math.cos(phi + 3.14159265359); //offset by pi
            let sinphi_5 = Math.sin(phi + 3.14159265359);
            let cosphi_6 = Math.cos(phi - 2.35619449019); //offset by 3pi/4
            let sinphi_6 = Math.sin(phi - 2.35619449019);
            let cosphi_7 = Math.cos(phi - 1.57079632679); //offset by pi/2
            let sinphi_7 = Math.sin(phi - 1.57079632679);
            let cosphi_8 = Math.cos(phi - 0.785398163); //offset by -pi/4
            let sinphi_8 = Math.sin(phi - 0.785398163);

            p1 = [0, 20.62 * sintheta, 38 * sintheta,  20.62 * sintheta + r * costheta * cosphi, 20.62 * sintheta + r * costheta * cosphi_2, 20.62 * sintheta + r * costheta * cosphi_3,20.62 * sintheta + r * costheta * cosphi_4, 20.62 * sintheta + r * costheta * cosphi_5, 20.62 * sintheta + r * costheta * cosphi_6, 20.62 * sintheta + r * costheta * cosphi_7, 20.62 * sintheta + r * costheta * cosphi_8, 20.62 * sintheta + r * costheta * cosphi];// reads like a matrix
            p2 = [0, 0, 0, r * sinphi, r*sinphi_2, r*sinphi_3,r*sinphi_4, r*sinphi_5, r*sinphi_6, r*sinphi_7, r*sinphi_8,  r * sinphi];
            p3 = [0, 20.62 * costheta,  38 * costheta,  20.62 * costheta - r * cosphi * sintheta, 20.62 * costheta - r * sintheta * cosphi_2, 20.62 * costheta - r * sintheta * cosphi_3, 20.62 * costheta - r * sintheta * cosphi_4, 20.62 * costheta - r * sintheta * cosphi_5, 20.62 * costheta - r * sintheta * cosphi_6, 20.62 * costheta - r * sintheta * cosphi_7, 20.62 * costheta - r * sintheta * cosphi_8, 20.62 * costheta - r * cosphi * sintheta];

            for (let i = 0; i < p1.length; i++) { // applying rotation matrix as a for loop (rotation around z axis)
                let a = p1[i];
                p1[i] = a * cosazimuth - p2[i] * sinazimuth;
                p2[i] = a * sinazimuth + p2[i] * cosazimuth;
                } //p3 stays the same, because it's a rotation about the z axis.


            if (v.toggleChoice == false) {
                Plotly.animate("test", {
                        data: [{
                            x: p1, y: p2, z: p3
                        }],// dont touch this (apart from to change the variables)!!
                        traces: [0],
                        layout: {
                            "camera": {}
                        },
                    }, {
                        transition: {duration: 0},
                        frame: {
                            duration: 0,
                            redraw: true
                        }
                    }
                )
            }
            t += 1/3; //tells the azimuthal and polar angles to keep changing in the for loop
                // }
            //when the time variable reaches a certain value, then it starts again
        return t
        }


        function calc() {// generates the positions of the points which are passed into the handle_slider function to be plotted
            let theta = v.thetaVal;
            let phi = 0 ;
            let azimuth = 0;
            let costheta = Math.cos(theta);
            let sintheta = Math.sin(theta);
            let cosazimuth = Math.cos(azimuth);
            let sinazimuth = Math.sin(azimuth);
            let cosphi = Math.cos(phi); // the first ones
            let sinphi = Math.sin(phi);
            let cosphi_2 = Math.cos(phi + 0.785398163); //offset by pi/4
            let sinphi_2 = Math.sin(phi + 0.785398163);
            let cosphi_3 = Math.cos(phi + 1.57079632679); //offset by pi/2
            let sinphi_3 = Math.sin(phi + 1.57079632679);
            let cosphi_4 = Math.cos(phi + 2.35619449019); //offset by 3pi/4
            let sinphi_4 = Math.sin(phi + 2.35619449019);
            let cosphi_5 = Math.cos(phi + 3.14159265359); //offset by pi
            let sinphi_5 = Math.sin(phi + 3.14159265359);
            let cosphi_6 = Math.cos(phi - 2.35619449019); //offset by 3pi/4
            let sinphi_6 = Math.sin(phi - 2.35619449019);
            let cosphi_7 = Math.cos(phi - 1.57079632679); //offset by pi/2
            let sinphi_7 = Math.sin(phi - 1.57079632679);
            let cosphi_8 = Math.cos(phi - 0.785398163); //offset by -pi/4
            let sinphi_8 = Math.sin(phi - 0.785398163);


            p1 = [0, 20.62 * sintheta, 38 * sintheta,  20.62 * sintheta + r * costheta * cosphi, 20.62 * sintheta + r * costheta * cosphi_2, 20.62 * sintheta + r * costheta * cosphi_3,20.62 * sintheta + r * costheta * cosphi_4, 20.62 * sintheta + r * costheta * cosphi_5, 20.62 * sintheta + r * costheta * cosphi_6, 20.62 * sintheta + r * costheta * cosphi_7, 20.62 * sintheta + r * costheta * cosphi_8, 20.62 * sintheta + r * costheta * cosphi];// reads like a matrix
            p2 = [0, 0, 0, r * sinphi, r*sinphi_2, r*sinphi_3,r*sinphi_4, r*sinphi_5, r*sinphi_6, r*sinphi_7, r*sinphi_8,  r * sinphi];
            p3 = [0, 20.62 * costheta,  38 * costheta,  20.62 * costheta - r * cosphi * sintheta, 20.62 * costheta - r * sintheta * cosphi_2, 20.62 * costheta - r * sintheta * cosphi_3, 20.62 * costheta - r * sintheta * cosphi_4, 20.62 * costheta - r * sintheta * cosphi_5, 20.62 * costheta - r * sintheta * cosphi_6, 20.62 * costheta - r * sintheta * cosphi_7, 20.62 * costheta - r * sintheta * cosphi_8, 20.62 * costheta - r * cosphi * sintheta];

            for (let i = 0; i < p1.length; i++) { // applying rotation matrix using a for loop, currently works
                let a = p1[i];
                p1[i] = a * cosazimuth - p2[i] * sinazimuth;
                p2[i] = a * sinazimuth + p2[i] * cosazimuth;
            } return p1,p2,p3
        }

        function handle_slider(){// plots the points of the gyroscope whenever the value of the slider is changed
            calc();
                    Plotly.animate("test", {
                    data: [{
                        x: p1,
                        y: p2,
                        z: p3 }
                    ],
                    traces: [0],
                    layout: {"camera": {
                }},
            }, {
                transition: {duration: 0},
                frame: {duration: 0,
                redraw: true
                }
            }
            );
            return theta
        }



        function animate(){
            requestAnimationFrame(animate);

            if(v.resetButton==true){
                reset();
                v.resetButton = false;
            }

            if(v.toggleChanged==true){
                toggle();
                v.toggleChanged=false;
            }



            if(v.hasSliderChanged==true){
                handle_slider();
                v.hasSliderChanged=false;
                
            }
            
        }

        animate();

    }
}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}
</style>