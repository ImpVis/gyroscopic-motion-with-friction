<template>
    <div>
        <iv-visualisation :title="pageName" :vue_config="vue_config" :page_number="2">
            <template #hotspots>

                <iv-toggle-hotspot position="bottom" title="Controls" style=" z-index: 2;">
                    
                    <div style="width:100%; float:bottom;">
                     
                        <label for="momslider">  Moment of Inertia of gyroscope wheel (about the rod): </label>
                        <iv-slider id="mom" ref="momController" :resetButton=false @click="resetGyro" @sliderChangedbyDragging="sliderChange" @sliderChangedbyClick="sliderChange" theme="Lime" :min="10" :max="25" :init_val="10" :step="0.1" :tick_step="5" />

                    </div>



                    <div style="width:100%; float:bottom;">
                        <div style="width: 100px; float:left; margin:10px">
                            <label for="toggleBasic1"> Stop/Start </label>
                            <iv-toggle-basic id="toggleBasic1" @input="stopStartChange"> </iv-toggle-basic>
                            
                            
                            <!-- <label for="toggle1"> Stop/Start  </label>
                            <div id="toggle1">
                                <label class="switch">
                                <input type="checkbox" @click="stopStartChange">
                                <span class="slider round"></span>
                                </label>
                            </div> -->


                        
                        </div>

                        <div style="width: 100px; float:right; margin:10px">
                            <label for="toggleBasic2"> Friction Off/On </label>
                            <iv-toggle-basic id="toggleBasic2" @input="frictionChange"> </iv-toggle-basic>
                            
                            <!-- <label for="toggle2"> Friction Off/On </label>
                            <div id="toggle2">
                                <label class="switch">
                                <input type="checkbox" @click="frictionChange">
                                <span class="slider round"></span>
                                </label>
                            </div> -->

                            
                        </div>

              
                    </div>
                    
                </iv-toggle-hotspot>

                <iv-pane position="left" format="push">
                    <iv-sidebar-content :showPagination="true">
                        <iv-sidebar-section title="Instructions" icon="question" theme="Lime">
                            <p>
                                Press the stop/start toggle in the controls tab to start the animation.
                            </p>
                            <p>
                                What do you think would happen if we changed the moment of intertia of the gyroscope wheel 
                                about the rod? Adjust it in the controls tab to see what happens.
                            </p>       
                            <p>
                                What do you think would happen if we introduced friction to our idealised system?
                                Click the 'friction on' button to see what happens. 
                            </p>
                           
                                                 
                        </iv-sidebar-section>
                        
                        <iv-sidebar-section title="Theory" icon="microscope" >
                            <p>
                                Consider a precessing gyroscope that is just about to touch the floor - the diagram 
                                below is a bird's-eye view of this. 
                                <img src = "assets/diagram.png" width=100% height=100% >
                            </p>
                            <p>
                                The radius, r, of a circle multiplied by the angle subtended, θ, gives the arc length, l. Then, at constant radius, for 
                                very small amplitudes,
                               
                                <iv-equation-box :stylise="false" equation="dl = r * d \theta "/>.

                                From this, we obtain
                                <iv-equation-box :stylise="false" equation="\frac{\dot{L}(t)}{L}= \dot{\theta(t)}"/>.
                            </p>
                            <p>
                                
                                Noticing that 
                                <iv-equation-box :stylise="false" equation="\dot{L}(t) = Rmg "/>,
                                <iv-equation-box :stylise="false" equation="L = Iw"/>,
                                and <iv-equation-box :stylise="false" equation="\dot{\theta(t)} = \omega_{precession}"/>,
                                we can obtain  <iv-equation-box :stylise="true" equation="\omega_{precession} = \frac{Rmg}{Iw}"/>
                            </p>
                            <p> 
                                (Note: Precession means rotation about the z axis, not the gyroscope's own axis.)
                            </p>
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Explanation" theme="Purple">
                            <p>
                                From this formula, we can see that the larger the moment of inertia 
                                of the flywheel about the rod passing through it (I), at constant mass (m), the 
                                slower the rate of precession. Notice that when the wheel rotation decreases due to 
                                frictional forces, the ω in the denominator decreases, which increases the rate of 
                                precession. 
                            </p>

                            <p>
                                When the gyroscope wheel begins to slow down due to friction, so that ω decreases, 
                                the angular momentum of the gyroscope (Iω) decreases. The torque (R×mg), however, 
                                remains unchanged (at the same angle to the vertical) so the change in angular momentum 
                                due to the torque is larger in comparison to the angular momentum due to the wheel rotation (Iω). 
                                As a result, the gyroscope "follows" the torque at a faster rate, as the torque is the rate of 
                                change of angular momentum. 
                            </p>

                            <p>
                                Initially, when the gyroscope begins to fall down, it loses some gravitational potential 
                                energy which supplies kinetic energy for its' precession. If the loss of angular momentum
                                of the flywheel about the rod, due to frictional forces acting on the wheel, can be neglected, 
                                then we can explain the deviation of the gyroscope's rotation axis (about it's rod) away 
                                from the z-axis (where it was initially) to balance the increase in angular momentum about 
                                the z axis due to the precession about the z axis, so that the angular momentum about the 
                                z axis would be conserved. If there were no frictional forces, the angular momentum about 
                                the z axis would be totally conserved as it is always perpendicular to the torque. 
                            </p>

                                
                        </iv-sidebar-section>
                        
                    </iv-sidebar-content>
                </iv-pane>

            </template>
                
            <div class="iv-welcome-message">
                <label for="7 columns">Gyroscopic motion: </label>
                <div class="7 columns" id="test" position="right"> </div>                    
            </div>  
            
        </iv-visualisation>
    </div>
</template>
<script>
import vue_config from '../../vue.config.js'
import Plotly from 'plotly.js/dist/plotly.min.js';
export default {
    name:"friction",
    data(){
        return {
            pageName:"Gyroscopes - moment of inertia and friction",
            vue_config,
            resetButton:false,
            stopStartChanged:false,
            frictionChanged:false,
            stopStartChoice:false,
            frictionChoice:false,
            hasSliderChanged:false,
            momVal:10
        }
    },
    methods:{
        resetGyro(){
            this.resetButton = true;
            },

        stopStartChange(e){
            
            this.stopStartChoice=e;
            this.stopStartChanged=true;
        },



        // stopStartChange(){
            
        //     this.stopStartChanged=true;
        // },

        frictionChange(e){
            
            this.frictionChoice=e;
            this.frictionChanged=true;
        },

        // frictionChange(){
            
        //     this.frictionChanged=true;
        // },

        sliderChange(e){
            this.momVal=e;
            this.hasSliderChanged=true;
        },


    },

    mounted(){
        let v = this;
        let plt = { //layout features
            MaxTraceNo: 12,
            layout: {
                autosize: true,
                margin: {
                    l: 0, r: 0, b: 0, t: 1, pad: 5
                },
                scene: {
                    aspectmode: "cube",
                    xaxis: {
                        range: [-40, 40], autorange: false, zeroline: true, showspikes: false
                    },
                    yaxis: {
                        range: [-40, 40], autorange: false, zeroline: true, showspikes: false
                    },
                    zaxis: {
                        range: [-40, 40], autorange: false, zeroline: true, showspikes: false
                    }
                },
                hovermode: false,
                font: {
                    family: "Fira Sans",
                    size: 14
                }
            },
        };

        
        let p1, p2, p3; // these 3 will become the 3 dimensional array of arrays that form the gyroscope
        let t = 0; //so that the visualisation starts at the beginning
        let r = 10; // default radius of the gyroscope
        //let played; // boolean variable that stores if button pressed or not
        let anim; // animation variable for gyroscope
        let speedup = false; //initially playing at normal speed
        let rate;
        let frictiontoggle;

        let azimuth = 0;
        let theta = 0;
        let phi = 0;

    
        let costheta = Math.cos(theta);
        let sintheta = Math.sin(theta);
        let cosphi = Math.cos(phi);
        let sinphi = Math.sin(phi);
        //below are the variables and points that make up the gyroscope wheel
        let cosphi_2 = Math.cos(phi + 0.785398163); //offset by pi/4
        let sinphi_2 = Math.sin(phi + 0.785398163);
        let cosphi_3 = Math.cos(phi + 1.57079632679); //offset by pi/2
        let sinphi_3 = Math.sin(phi + 1.57079632679);
        let cosphi_4 = Math.cos(phi + 2.35619449019); //offset by 3pi/4
        let sinphi_4 = Math.sin(phi + 2.35619449019);
        let cosphi_5 = Math.cos(phi + 3.14159265359); //offset by pi
        let sinphi_5 = Math.sin(phi + 3.14159265359);
        let cosphi_6 = Math.cos(phi - 2.35619449019); //offset by 3pi/4
        let sinphi_6 = Math.sin(phi - 2.35619449019);
        let cosphi_7 = Math.cos(phi - 1.57079632679); //offset by pi/2
        let sinphi_7 = Math.sin(phi - 1.57079632679);
        let cosphi_8 = Math.cos(phi - 0.785398163); //offset by -pi/4
        let sinphi_8 = Math.sin(phi - 0.785398163);

        // x, y and z values of the gyroscopes

        p1 = [0, 20.62 * sintheta, 38 * sintheta, 20.62 * sintheta + r * costheta * cosphi, 20.62 * sintheta + r * costheta * cosphi_2, 20.62 * sintheta + r * costheta * cosphi_3, 20.62 * sintheta + r * costheta * cosphi_4, 20.62 * sintheta + r * costheta * cosphi_5, 20.62 * sintheta + r * costheta * cosphi_6, 20.62 * sintheta + r * costheta * cosphi_7, 20.62 * sintheta + r * costheta * cosphi_8, 20.62 * sintheta + r * costheta * cosphi];// reads like a matrix
        p2 = [0, 0, 0, r * sinphi, r * sinphi_2, r * sinphi_3, r * sinphi_4, r * sinphi_5, r * sinphi_6, r * sinphi_7, r * sinphi_8, r * sinphi];
        p3 = [0, 20.62 * costheta, 38 * costheta, 20.62 * costheta - r * cosphi * sintheta, 20.62 * costheta - r * sintheta * cosphi_2, 20.62 * costheta - r * sintheta * cosphi_3, 20.62 * costheta - r * sintheta * cosphi_4, 20.62 * costheta - r * sintheta * cosphi_5, 20.62 * costheta - r * sintheta * cosphi_6, 20.62 * costheta - r * sintheta * cosphi_7, 20.62 * costheta - r * sintheta * cosphi_8, 20.62 * costheta - r * cosphi * sintheta];

        let int = {
            type: "scatter3d",
            x: p1,
            y: p2,
            z: p3,
        };

        // let canvas = document.querySelector('canvas');  /// to draw the image in the theory pane, which has since just been added as a png
        // let ctx = canvas.getContext('2d');
        // ctx.scale(1, 1); //scale of the canvas
        // function initPlot_gyro() {
        //     /** --------------------------------- Set initial plot - drawing - what is displayed initially --------------------------------- **/
        //     ctx.clearRect(0, 0, canvas.width, canvas.height);
        //     // Creates plot for gyroscope by drawing lines
        //     ctx.beginPath();
        //     ctx.moveTo(0,200);
        //     ctx.lineTo(500, 100);
        //     ctx.moveTo(0,200);
        //     ctx.lineTo(500,200);
        //     ctx.lineTo(500,100);
        //     ctx.moveTo(0,200);
        //     ctx.arc(0, 200, 175, 0, (Math.PI/180)*(349),true);
        //     ctx.stroke();

        //     //parameters for drawing
        //     ctx.fillStyle = "black";
        //     ctx.font = "italic 15pt san-serif";
        //     ctx.fillText("dL", 507, 150);
        //     ctx.fillText("L", 400, 190);
        //     ctx.stroke(); //THIS IS REQUIRED

        // // text for the labels on the gyroscope diagram

        //     ctx.fillStyle = "black";
        //     ctx.font = "italic 15pt san-serif";
        //     ctx.fillText("d\u03B8", 100, 195);
        //     ctx.stroke();
        // }



        Plotly.newPlot("test", [int], plt.layout); // shows the first plot when the page is loaded
        //Plotly.plot("test", [int2], plt.layout);
       

        function frictiontoggler() {
            if (frictiontoggle === true) {

                frictiontoggle = false;

            }
            else {

                frictiontoggle = true;
 
            }

        }
        //generating and plotting a graph of gyroscope precession rate

        // var graphlayout1 = {
        //     title: 'Plot of energies against time',
        //     xaxis: {
        //         title: 'Time/s'
        //     },
        //     yaxis: {
        //         title: 'Energy as a fraction of the total energy'
        //     }
        // };

        // let totalke = {
        //     mode: "scatter",
        //     x: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        //     y: [1,1,1,1,1,1,1,1,1,1],//let phi = -0.0065*t**2 + 15*t+25 ; //doesn't seem to be changing whenev
        //     name: 'Total Energy of the gyroscope'
        // };

        // let gpe = {
        //     mode: "scatter",
        //     x: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        //     y: [1,0.3678794412,0.1353352832,0.04978706837,0.0183156,0.006737946,0.0024787521,0.000911882,0.0003354626,0.0001234098041],
        //     //let phi = -0.0065*t**2 + 15*t+25 ; //doesn't seem to be changing whenev
        //     name: "Gyroscope GPE"
        // };

        // let ke = {
        //     mode: "scatter",
        //     x: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        //     y: [0, 0.6321205589, 0.8646647168, 0.9502129316, 0.9816843611, 0.993262053, 0.9975212478, 0.999088118, 0.9996645374, 0.9998765902, 0.9999546001],//let phi = -0.0065*t**2 + 15*t+25 ; //doesn't seem to be changing whenev
        //     name: "Gyroscope KE"
        // };

        //Plotly.plot("energygraph", [totalke,gpe,ke], graphlayout1);

        // graph slider show and hide

        // $('.graphSlider').on('click', function () {
        //     let text = $($(this).children('.showhide')[0]).is(":hidden") ? ["Hide " + $($(this).children('.showhide')).attr('label'), 180] : ["Show " + $($(this).children('.showhide')).attr('label'), 0];
        //     //$($(this).children('.showhide')[0]).slideToggle(400);
        //     $($(this).children("span")[0]).html(text[0]);
        //     $($(this).children("svg")[0]).css("transform", "rotate(" + text[1] + "deg)");
        // });

        function inertia_decision() { //if played = true the inertia is changed during the animation
            //console.log("inertia decision");
            if (v.stopStartChoice === true) { //the gyroscope wheel radius is also changed and the corresponding precession rate
                play() // the play function is called, which executes another step in the gyro movement
            }
            else {
                handle_slider(); //if the animation is not going then the handle slider function is called and the ring radius changed - instead of getting the gyro to move
            }

        }

        function reset() { //resets all parameters to their initial values and plots the gyro in its initial position
            v.stopStartChoice = true;
            t = 0;
            toggle();
            //let azimuth = 0;
            let theta = 0;
            let phi = 0; //doesn't seem to be changing whenever i change the power of i????
            let r = 10;
            let costheta = Math.cos(theta);
            let sintheta = Math.sin(theta);
            let cosphi = Math.cos(phi);
            let sinphi = Math.sin(phi);
            //below are the variables and points that make up the gyroscope wheel
            let cosphi_2 = Math.cos(phi + 0.785398163); //offset by pi/4
            let sinphi_2 = Math.sin(phi + 0.785398163);
            let cosphi_3 = Math.cos(phi + 1.57079632679); //offset by pi/2
            let sinphi_3 = Math.sin(phi + 1.57079632679);
            let cosphi_4 = Math.cos(phi + 2.35619449019); //offset by 3pi/4
            let sinphi_4 = Math.sin(phi + 2.35619449019);
            let cosphi_5 = Math.cos(phi + 3.14159265359); //offset by pi
            let sinphi_5 = Math.sin(phi + 3.14159265359);
            let cosphi_6 = Math.cos(phi - 2.35619449019); //offset by 3pi/4
            let sinphi_6 = Math.sin(phi - 2.35619449019);
            let cosphi_7 = Math.cos(phi - 1.57079632679); //offset by pi/2
            let sinphi_7 = Math.sin(phi - 1.57079632679);
            let cosphi_8 = Math.cos(phi - 0.785398163); //offset by -pi/4
            let sinphi_8 = Math.sin(phi - 0.785398163);

            p1 = [0, 20.62 * sintheta, 38 * sintheta, 20.62 * sintheta + r * costheta * cosphi, 20.62 * sintheta + r * costheta * cosphi_2, 20.62 * sintheta + r * costheta * cosphi_3, 20.62 * sintheta + r * costheta * cosphi_4, 20.62 * sintheta + r * costheta * cosphi_5, 20.62 * sintheta + r * costheta * cosphi_6, 20.62 * sintheta + r * costheta * cosphi_7, 20.62 * sintheta + r * costheta * cosphi_8, 20.62 * sintheta + r * costheta * cosphi];// reads like a matrix
            p2 = [0, 0, 0, r * sinphi, r * sinphi_2, r * sinphi_3, r * sinphi_4, r * sinphi_5, r * sinphi_6, r * sinphi_7, r * sinphi_8, r * sinphi];
            p3 = [0, 20.62 * costheta, 38 * costheta, 20.62 * costheta - r * cosphi * sintheta, 20.62 * costheta - r * sintheta * cosphi_2, 20.62 * costheta - r * sintheta * cosphi_3, 20.62 * costheta - r * sintheta * cosphi_4, 20.62 * costheta - r * sintheta * cosphi_5, 20.62 * costheta - r * sintheta * cosphi_6, 20.62 * costheta - r * sintheta * cosphi_7, 20.62 * costheta - r * sintheta * cosphi_8, 20.62 * costheta - r * cosphi * sintheta];


            int = {
                type: "scatter3d",
                x: p1, //should be the default p1, p2 and p3
                y: p2, //should be the default p1, p2 and p3
                z: p3,
            };
            Plotly.purge("test");
            Plotly.newPlot("test", [int], plt.layout);
        }

        // function speed_toggle() { //this is a button to speed up/slow down
        //     if (speedup === true) {
        //         $("#speedupButton").html("Speed up");
        //         speedup = false;
        //     }
        //     else {
        //         $("#speedupButton").html("Slow down");
        //         speedup = true;
        //         //console.log("now should be repeating");
        // //      anim = setInterval(play, 20);
        //         //played = true
        //     }
        //     return speedup
        // }

        function toggle() { //changing the button text and starting/stopping the gyro
          
            if (v.stopStartChoice === true) {
                //$("#playPauseButton").html("play");
                v.stopStartChoice = false;
                clearInterval(anim); //the clear interval means that it only stops at the end of the animation
                //$("div#test").stop(true, true);
            }
            else {
                //$("#playPauseButton").html("pause");
                v.stopStartChoice = true;
                //console.log("now should be repeating");
                anim = setInterval(play, 20);
            }
            return v.stopStartChoice
        }


        // function draw_arrow(obj, pointsx, pointsy, pointsz, color) {
        //     /* Returns an arrowhead based on an inputted line */
        //     var x = pointsx[1],
        //         y = pointsy[1],
        //         z = pointsz[1],
        //         u = 0.2*(pointsx[1] - pointsx[0]),
        //         v = 0.2*(pointsy[1] - pointsy[0]),
        //         w = 0.2*(pointsz[1] - pointsz[0]);
        //     obj.push({
        //         type: "cone",
        //         colorscale: [[0, color],[1,color]],
        //         x: [x],
        //         y: [y],
        //         z: [z],
        //         u: [u],
        //         v: [v],
        //         w: [w],
        //         sizemode: "absolute",
        //         sizeref: 30,//0.3*Math.sqrt(Vector.fromArray([x,y,z]).length()),
        //         showscale: false,
        //         legendgroup: 's',
        //     });
        // };


        function play() { //plots the gyroscope (with a parameter t that changes, so the gyroscope position changes with time)
            if (speedup === true) {
                rate = 1.6
                
            }
            else {
                rate = 1
                
            }
            let r = v.momVal //taking the value of radius from the slider
            if (frictiontoggle === true) {
                azimuth = t ** 1.45 * (3.14159265359 / 180) * 400 / r;   //how the azimuthal angle that the gyro makes with the x axis
                theta = (3.14159265359 / 80) * t; //how theta changes over time
                if (t < 18.75){ //phi changes over time, until it stops
                    phi = -0.12 * t ** 2 + 4.5 * t
                }
                else
                    {
                        phi = 42.1875;

                    }
                }
            else{
                azimuth = t * (3.14159265359 / 180) * 800 / r;   //how the azimuthal angle that the gyro makes with the x axis
                theta = (0.25*3.14159265359); //how theta changes over time
                phi =  18 * t
            //phi changes over time, until it stops
                }

            //let gpetoke = 6 + 0.5 * t ** 1.05; // how the value of the slider value changes over time
            let costheta = Math.cos(theta);
            let sintheta = Math.sin(theta);
            let cosphi = Math.cos(phi);
            let sinphi = Math.sin(phi);
            //below are the variables and points that make up the gyroscope wheel
            let cosazimuth = Math.cos(azimuth);
            let sinazimuth = Math.sin(azimuth);
            let cosphi_2 = Math.cos(phi + 0.785398163); //offset by pi/4
            let sinphi_2 = Math.sin(phi + 0.785398163);
            let cosphi_3 = Math.cos(phi + 1.57079632679); //offset by pi/2
            let sinphi_3 = Math.sin(phi + 1.57079632679);
            let cosphi_4 = Math.cos(phi + 2.35619449019); //offset by 3pi/4
            let sinphi_4 = Math.sin(phi + 2.35619449019);
            let cosphi_5 = Math.cos(phi + 3.14159265359); //offset by pi
            let sinphi_5 = Math.sin(phi + 3.14159265359);
            let cosphi_6 = Math.cos(phi - 2.35619449019); //offset by 3pi/4
            let sinphi_6 = Math.sin(phi - 2.35619449019);
            let cosphi_7 = Math.cos(phi - 1.57079632679); //offset by pi/2
            let sinphi_7 = Math.sin(phi - 1.57079632679);
            let cosphi_8 = Math.cos(phi - 0.785398163); //offset by -pi/4
            let sinphi_8 = Math.sin(phi - 0.785398163);

            p1 = [0, 20.62 * sintheta, 38 * sintheta, 20.62 * sintheta + r * costheta * cosphi, 20.62 * sintheta + r * costheta * cosphi_2, 20.62 * sintheta + r * costheta * cosphi_3, 20.62 * sintheta + r * costheta * cosphi_4, 20.62 * sintheta + r * costheta * cosphi_5, 20.62 * sintheta + r * costheta * cosphi_6, 20.62 * sintheta + r * costheta * cosphi_7, 20.62 * sintheta + r * costheta * cosphi_8, 20.62 * sintheta + r * costheta * cosphi];// reads like a matrix
            p2 = [0, 0, 0, r * sinphi, r * sinphi_2, r * sinphi_3, r * sinphi_4, r * sinphi_5, r * sinphi_6, r * sinphi_7, r * sinphi_8, r * sinphi];
            p3 = [0, 20.62 * costheta, 38 * costheta, 20.62 * costheta - r * cosphi * sintheta, 20.62 * costheta - r * sintheta * cosphi_2, 20.62 * costheta - r * sintheta * cosphi_3, 20.62 * costheta - r * sintheta * cosphi_4, 20.62 * costheta - r * sintheta * cosphi_5, 20.62 * costheta - r * sintheta * cosphi_6, 20.62 * costheta - r * sintheta * cosphi_7, 20.62 * costheta - r * sintheta * cosphi_8, 20.62 * costheta - r * cosphi * sintheta];


            for (let i = 0; i < p1.length; i++) { // applying rotation matrix as a for loop (rotation around z axis)
                let a = p1[i];
                p1[i] = a * cosazimuth - p2[i] * sinazimuth;
                p2[i] = a * sinazimuth + p2[i] * cosazimuth;
            } //p3 stays the same, because it's a rotation about the z axis.

            if (v.stopStartChoice === true) {
                let data_plotted = [];
                let points = {//add trace for line of field line
                            type: "scatter3d",
                            mode: "points",
                            name: "gyro",
                            //line: {color: "blue"},
                            x: p1,
                            y: p2,
                            z: p3
                        };

                data_plotted.push(points);


                /*let lines = {//L vector
                            name: 'Angular momentum',
                            type: 'scatter3d',
                            mode: 'lines',
                            line: {width: 10, dash: 'solid', color: '#DC143C'},
                            legendgroup: 'l',
                                x: [1, 5,2],
                                y: [1, 5,2],
                                z: [1, 5,2],
                        };
                //data_plotted.push(lines);
                data_plotted.push(points);

            points.x.push(lines.x)
            points.y.push(lines.y)
            points.z.push(lines.z)

                draw_arrow(data_plotted, [0,100], [0,100], [0,100]);*/

                Plotly.animate("test",
                    {data: data_plotted}, {
                        transition: {duration: 0},
                        frame: {
                            duration: 0,
                            redraw: true
                        }
                    }
                )
                /*
                Plotly.animate("test",
                    {data : lines,}, {
                        transition: {duration: 0},
                        frame: {
                            duration: 0,
                            redraw: true
                        }
                    }
                )
                */

            } 

            if (t < 35) {
                t += (rate / 15)
            } //tells the azimuthal and polar angles to keep changing in the for loop
            else {
                t = 0; //when the time reaches a certain point, then it starts again
            }
            return t; // the "time" parameter is returned so it can be used in the reset function
        }

        function handle_slider() { // plots the new points of the gyroscope whenever the value of the slider is changed

            let theta = 0;
            let phi = 0;
            let costheta = Math.cos(theta);
            let sintheta = Math.sin(theta);
            let cosphi = Math.cos(phi); // the first ones
            let sinphi = Math.sin(phi);
            let cosphi_2 = Math.cos(phi + 0.785398163); //offset by pi/4
            let sinphi_2 = Math.sin(phi + 0.785398163);
            let cosphi_3 = Math.cos(phi + 1.57079632679); //offset by pi/2
            let sinphi_3 = Math.sin(phi + 1.57079632679);
            let cosphi_4 = Math.cos(phi + 2.35619449019); //offset by 3pi/4
            let sinphi_4 = Math.sin(phi + 2.35619449019);
            let cosphi_5 = Math.cos(phi + 3.14159265359); //offset by pi
            let sinphi_5 = Math.sin(phi + 3.14159265359);
            let cosphi_6 = Math.cos(phi - 2.35619449019); //offset by 3pi/4
            let sinphi_6 = Math.sin(phi - 2.35619449019);
            let cosphi_7 = Math.cos(phi - 1.57079632679); //offset by pi/2
            let sinphi_7 = Math.sin(phi - 1.57079632679);
            let cosphi_8 = Math.cos(phi - 0.785398163); //offset by -pi/4
            let sinphi_8 = Math.sin(phi - 0.785398163);


            let r = v.momVal; //taking the value of radius from the slider

            p1 = [0, 20.62 * sintheta, 38 * sintheta, 20.62 * sintheta + r * costheta * cosphi, 20.62 * sintheta + r * costheta * cosphi_2, 20.62 * sintheta + r * costheta * cosphi_3, 20.62 * sintheta + r * costheta * cosphi_4, 20.62 * sintheta + r * costheta * cosphi_5, 20.62 * sintheta + r * costheta * cosphi_6, 20.62 * sintheta + r * costheta * cosphi_7, 20.62 * sintheta + r * costheta * cosphi_8, 20.62 * sintheta + r * costheta * cosphi];// reads like a matrix
            p2 = [0, 0, 0, r * sinphi, r * sinphi_2, r * sinphi_3, r * sinphi_4, r * sinphi_5, r * sinphi_6, r * sinphi_7, r * sinphi_8, r * sinphi];
            p3 = [0, 20.62 * costheta, 38 * costheta, 20.62 * costheta - r * cosphi * sintheta, 20.62 * costheta - r * sintheta * cosphi_2, 20.62 * costheta - r * sintheta * cosphi_3, 20.62 * costheta - r * sintheta * cosphi_4, 20.62 * costheta - r * sintheta * cosphi_5, 20.62 * costheta - r * sintheta * cosphi_6, 20.62 * costheta - r * sintheta * cosphi_7, 20.62 * costheta - r * sintheta * cosphi_8, 20.62 * costheta - r * cosphi * sintheta];

            Plotly.animate("test", { // actively plotting the gyroscope
                    data: [{ //use plotly.animate instead of plotly.plot as plotly.plot plots NEW plots ON TOP OF old ones whereas animate changes the current ones.
                        x: p1, y: p2, z: p3
                    }
                    ],
                    traces: [0],
                    layout: {
                        "camera": {}
                    },
                }, {
                    transition: {duration: 0},
                    frame: {
                        duration: 0,
                        redraw: true
                    }
                }
            )

        }
        
        function animate(){
            requestAnimationFrame(animate);

            if(v.resetButton==true){
                reset();
                v.resetButton = false;
            }

            if(v.stopStartChanged==true){
                toggle();
                v.stopStartChanged=false;
            }

            if(v.frictionChanged==true){
                frictiontoggler();
                v.frictionChanged=false;
            }

            if(v.hasSliderChanged==true){
                inertia_decision();
                v.hasSliderChanged=false;
                
            }
        }
        animate();

    }

}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}

/* The switch - the box around the slider */
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

/* Hide default HTML checkbox */
.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

/* The slider */
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}

</style>